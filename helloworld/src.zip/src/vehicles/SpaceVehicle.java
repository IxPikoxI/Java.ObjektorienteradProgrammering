package vehicles;

public interface SpaceVehicle {
	void launch();
	void land();
	void transportCrew();
}
