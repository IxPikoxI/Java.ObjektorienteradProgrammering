package helloworld;

public class WorldFire1 {
	private String Math;
	
	public void setName(String Math) {
		this.Math = Math;
	}
	
	public String getName() {
		return Math;
	}

}
